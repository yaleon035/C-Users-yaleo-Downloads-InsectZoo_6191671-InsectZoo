/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insectzoo;

/**
 *
 * @author yaleo
 */
public class Bee extends Insect{
    
    boolean hasStinger;
    public Bee(int numberofLegs, int numberofEyes, int numberofWings) {
        super(numberofLegs, numberofEyes, numberofWings);
    }

    Bee() {
      super(6,4,4);
      hasStinger=true;
    }
    public String fly()
    {
         String insect = "bee fly sound:BbbbbB";
         System.out.println("bees  makes this sound when flyes "+insect);
        return insect;
        
    }

    public boolean isHasStinger() {
        return hasStinger;
    }

    public int getNumberofLegs() {
        return numberofLegs;
    }

    public int getNumberofEyes() {
        return numberofEyes;
    }

    public int getNumberofWings() {
        return numberofWings;
    }

    public void setHasStinger(boolean hasStinger) {
        this.hasStinger = hasStinger;
    }

    public void setNumberofLegs(int numberofLegs) {
        this.numberofLegs = numberofLegs;
    }

    public void setNumberofEyes(int numberofEyes) {
        this.numberofEyes = numberofEyes;
    }

    public void setNumberofWings(int numberofWings) {
        this.numberofWings = numberofWings;
    }
    
}
