/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insectzoo;

/**
 *
 * @author yaleo
 */
public class Mosquito extends Insect{
    
    boolean Dangerous;
    public Mosquito(int numberofLegs, int numberofEyes, int numberofWings) {
        super(numberofLegs, numberofEyes, numberofWings);
    }

    public Mosquito()
    {
     super(6,3,4);   
        Dangerous=true;
    }
    
    public String fly()
    {
        String insect = "sound:ZzzzzZ";
        
       System.out.println("mosquitos makes this sound when it flyes "+insect);
        return insect;
       
    }
    public boolean isDangerous() {
        return Dangerous;
    }

    public int getNumberofLegs() {
        return numberofLegs;
    }

    public int getNumberofEyes() {
        return numberofEyes;
    }

    public int getNumberofWings() {
        return numberofWings;
    }

    public void setDangerous(boolean Dangerous) {
        this.Dangerous = Dangerous;
    }

    public void setNumberofLegs(int numberofLegs) {
        this.numberofLegs = numberofLegs;
    }

    public void setNumberofEyes(int numberofEyes) {
        this.numberofEyes = numberofEyes;
    }

    public void setNumberofWings(int numberofWings) {
        this.numberofWings = numberofWings;
    }
    
}
