/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insectzoo;

/**
 *
 * @author yaleo
 */
public class Butterfly extends Insect {
    
    String WingColor;
    private int numberofWings;

     Butterfly(int numberofLegs, int numberofEyes, int numberofWings) {
        super(numberofLegs, numberofEyes, numberofWings);
    }

    public Butterfly() {
       super(6,2,4);
       WingColor="Yellow";
    }

    public String fly()
    {
        String insect = "butterfly sound:-----";
        
       System.out.println("butterfly makes this sound when flyes "+insect);
        return insect;
       
    }

    public String getWingColor() {
        return WingColor;
    }

    public int getNumberofLegs() {
        return numberofLegs;
    }

    public int getNumberofEyes() {
        return numberofEyes;
    }

    public int getNumberofWings() {
        return numberofWings;
    }
}
